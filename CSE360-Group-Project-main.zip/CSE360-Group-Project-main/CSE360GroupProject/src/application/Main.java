package application;

import backend.AuthManager;
import frontend.LoginScene.LoginScene;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * <p> Title: Main Class for the Application </p>
 * 
 * <p> Description: This is the main entry point of the application that initializes and launches the JavaFX interface.</p>
 * 
 * @author Zeel Tejashkumar Shah
 * 
 * @version 1.1 2024-10-23 Added H2 database integration.
 */

public class Main extends Application {

    private Connection connection;

    /**
     * <p> This method is called when the application is started. It sets up the primary stage and initializes the login scene. </p>
     * 
     * @param primaryStage The primary stage for this application, onto which the application scene can be set.
     */
    @Override
    public void start(Stage primaryStage) {
        
    	try {
            // Initialize H2 database connection
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");
            System.out.println("Connected to H2 database.");

            // Create AuthManager with database connection
            AuthManager authManager = new AuthManager(connection);

            // Create the login scene
            LoginScene loginScene = new LoginScene(primaryStage, authManager);
            Scene scene = loginScene.createLoginScene(); // Create the login scene

            primaryStage.setScene(scene); // Set the scene for the primary stage
            primaryStage.show(); // Display the primary stage
        } catch (ClassNotFoundException e) {
            System.err.println("H2 driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Error connecting to the H2 database: " + e.getMessage());
        }
    } // Close the start method

    /**
     * <p> The main method that serves as the entry point for the JavaFX application. </p>
     * 
     * @param args Command line arguments passed to the application.
     */
    public static void main(String[] args) {
        launch(args); // Launch the JavaFX application
    }

    /**
     * <p> This method is called when the application is stopped. It closes the database connection. </p>
     */
    @Override
    public void stop() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("H2 database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing the H2 database connection: " + e.getMessage());
        }
    }
}
