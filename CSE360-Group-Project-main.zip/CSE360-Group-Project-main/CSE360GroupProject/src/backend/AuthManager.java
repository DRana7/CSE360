package backend;

import java.sql.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class AuthManager {
    private Connection connection; // Database connection
    private ArrayList<User> users; // List of users

    // Constructor
    public AuthManager(Connection connection) {
        this.connection = connection;
        this.users = new ArrayList<>(); // Initialize users list here
        initializeDatabase(); // Initialize the database schema
    }

    public AuthManager() {
        this.users = new ArrayList<>(); // Initialize users list
    }

    private void initializeDatabase() {
        try (Statement stmt = connection.createStatement()) {
            // Create Users table
            stmt.execute("CREATE TABLE IF NOT EXISTS Users ("
                    + "username VARCHAR(255) PRIMARY KEY, "
                    + "password VARCHAR(255), "
                    + "firstName VARCHAR(255), "
                    + "middleName VARCHAR(255), "
                    + "lastName VARCHAR(255), "
                    + "preferredName VARCHAR(255), "
                    + "email VARCHAR(255), "
                    + "setupComplete BOOLEAN DEFAULT FALSE)");

            // Create Invitations table
            stmt.execute("CREATE TABLE IF NOT EXISTS Invitations ("
                    + "invitationCode VARCHAR(255) PRIMARY KEY, "
                    + "username VARCHAR(255), "
                    + "email VARCHAR(255), "
                    + "roles VARCHAR(255), "
                    + "used BOOLEAN DEFAULT FALSE)");

            // Create ResetRequests table
            stmt.execute("CREATE TABLE IF NOT EXISTS ResetRequests ("
                    + "email VARCHAR(255), "
                    + "otp VARCHAR(255), "
                    + "expirationTime TIMESTAMP)");
        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
        }
    }

    // ========== User Management Methods ========== //

    public User createFirstUser(String username, String password) {
        if (getAllUsers().isEmpty()) {
            User admin = new User(username, password, new HashSet<>(Arrays.asList(Role.ADMIN)));
            addUserToDatabase(admin);
            return admin;
        }
        return null;
    }

    public User createUser(String username, String password, Set<Role> roles) {
        User newUser = new User(username, password, roles);
        addUserToDatabase(newUser);
        return newUser;
    }

    public User login(String username, String password) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Users WHERE username = ? AND password = ?");
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(rs.getString("username"), rs.getString("password"), new HashSet<>(Arrays.asList(Role.ADMIN))); 
            }
        } catch (SQLException e) {
            System.err.println("Error during login: " + e.getMessage());
        }
        return null;
    }

    public boolean completeAccountSetup(User user, String firstName, String middleName, String lastName,
                                        String preferredName, String email) {
        user.setFirstName(firstName);
        user.setMiddleName(middleName);
        user.setLastName(lastName);
        user.setPreferredName(preferredName);
        user.setEmail(email);
        user.setSetupComplete(true);
        updateUserInDatabase(user);
        return true;
    }

    public User findUserByUsername(String username) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Users WHERE username = ?");
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Set<Role> roles = getRolesForUser(username);
                return new User(
                        rs.getString("username"),
                        rs.getString("password"),
                        roles,
                        rs.getString("firstName"),
                        rs.getString("middleName"),
                        rs.getString("lastName"),
                        rs.getString("preferredName"),
                        rs.getString("email")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error finding user: " + e.getMessage());
        }
        return null;
    }

    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Users");
            while (rs.next()) {
                Set<Role> roles = getRolesForUser(rs.getString("username"));
                userList.add(new User(
                        rs.getString("username"),
                        rs.getString("password"),
                        roles,
                        rs.getString("firstName"),
                        rs.getString("middleName"),
                        rs.getString("lastName"),
                        rs.getString("preferredName"),
                        rs.getString("email")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving users: " + e.getMessage());
        }
        return userList;
    }

    private Set<Role> getRolesForUser(String username) {
        // Implement logic to fetch roles for the user from the database
        return new HashSet<>();
    }

    public boolean userExistsForEmail(String email) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Users WHERE email = ?");
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("Error checking email existence: " + e.getMessage());
        }
        return false;
    }

    private void addUserToDatabase(User user) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO Users (username, password, firstName, middleName, lastName, preferredName, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getFirstName());
            stmt.setString(4, user.getMiddleName());
            stmt.setString(5, user.getLastName());
            stmt.setString(6, user.getPreferredName());
            stmt.setString(7, user.getEmail());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding user to database: " + e.getMessage());
        }
    }

    private void updateUserInDatabase(User user) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE Users SET firstName = ?, middleName = ?, lastName = ?, preferredName = ?, email = ?, setupComplete = ? WHERE username = ?");
            stmt.setString(1, user.getFirstName());
            stmt.setString(2, user.getMiddleName());
            stmt.setString(3, user.getLastName());
            stmt.setString(4, user.getPreferredName());
            stmt.setString(5, user.getEmail());
            stmt.setBoolean(6, user.isSetupComplete());
            stmt.setString(7, user.getUsername());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating user in database: " + e.getMessage());
        }
    }

    // ========== Invitation Management Methods ========== //

    public String inviteUser(String username, String email, Set<Role> roles) {
        Invitation newInvitation = new Invitation(connection, username, email, roles);
        addInvitationToDatabase(newInvitation);
        System.out.println("Invitation code for " + email + " : " + newInvitation.getInvitationCode());
        return newInvitation.getInvitationCode();
    }

    private void addInvitationToDatabase(Invitation invitation) {
        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO Invitations (invitationCode, username, email, roles) VALUES (?, ?, ?, ?)");
            stmt.setString(1, invitation.getInvitationCode());
            stmt.setString(2, invitation.getUsername());
            stmt.setString(3, invitation.getEmail());
            stmt.setString(4, String.join(",", invitation.getRoles().stream().map(Role::name).toArray(String[]::new)));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding invitation to database: " + e.getMessage());
        }
    }

    public void addRole(User user, Role role) {
        if (user != null && !user.getRoles().contains(role)) {
            user.getRoles().add(role);
            updateUserInDatabase(user); // Update roles in the database
        }
    }

    public void removeRole(User user, Role role) {
        if (user != null && user.getRoles().contains(role)) {
            user.getRoles().remove(role);
            updateUserInDatabase(user); // Update roles in the database
        }
    }

    public boolean isUserInvited(String invitationCode) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Invitations WHERE invitationCode = ? AND used = FALSE");
            stmt.setString(1, invitationCode);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("Error checking invitation: " + e.getMessage());
        }
        return false;
    }

    public Invitation getInvitationFromInvitationCode(String invitationCode) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Invitations WHERE invitationCode = ?");
            stmt.setString(1, invitationCode);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String username = rs.getString("username");
                String email = rs.getString("email");
                Set<Role> roles = Arrays.stream(rs.getString("roles").split(","))
                        .map(Role::valueOf).collect(Collectors.toSet());
                return new Invitation(invitationCode, username, email, roles);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving invitation: " + e.getMessage());
        }
        return null;
    }

    public void markInvitationAsUsed(String invitationCode) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE Invitations SET used = TRUE WHERE invitationCode = ?");
            stmt.setString(1, invitationCode);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error marking invitation as used: " + e.getMessage());
        }
    }

    // ========== Password Reset Methods ========== //

    public boolean requestPasswordReset(String email) {
        if (userExistsForEmail(email)) {
            String otp = generateOTP();
            Instant expirationTime = Instant.now().plus(10, ChronoUnit.MINUTES);
            storeResetRequest(email, otp, expirationTime);
            return true; // OTP generated and stored successfully
        }
        return false; // Email does not exist
    }

    private String generateOTP() {
        Random random = new Random();
        StringBuilder otpBuilder = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            otpBuilder.append(random.nextInt(10)); // Generate a random digit
        }
        return otpBuilder.toString();
    }

    private void storeResetRequest(String email, String otp, Instant expirationTime) {
        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO ResetRequests (email, otp, expirationTime) VALUES (?, ?, ?)");
            stmt.setString(1, email);
            stmt.setString(2, otp);
            stmt.setTimestamp(3, Timestamp.from(expirationTime));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error storing reset request: " + e.getMessage());
        }
    }

    public boolean validateOTP(String email, String otp) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM ResetRequests WHERE email = ? AND otp = ? AND expirationTime > NOW()");
            stmt.setString(1, email);
            stmt.setString(2, otp);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // If result set is not empty, OTP is valid
        } catch (SQLException e) {
            System.err.println("Error validating OTP: " + e.getMessage());
        }
        return false;
    }

    public void resetPassword(String email, String newPassword) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE Users SET password = ? WHERE email = ?");
            stmt.setString(1, newPassword);
            stmt.setString(2, email);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error resetting password: " + e.getMessage());
        }
    }
    

    public void deleteUser(User user) {
        try {
            // Remove the user from the Users table
            PreparedStatement stmt = connection.prepareStatement("DELETE FROM Users WHERE username = ?");
            stmt.setString(1, user.getUsername());
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("User '" + user.getUsername() + "' deleted from Users table.");
            } else {
                System.err.println("No user found with username: " + user.getUsername());
            }

            // Optionally, remove associated invitations if needed
            PreparedStatement invitationStmt = connection.prepareStatement("DELETE FROM Invitations WHERE username = ?");
            invitationStmt.setString(1, user.getUsername());
            invitationStmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error deleting user: " + e.getMessage());
        }
    }
 // This method retrieves the reset request associated with the given email address from the database.
    public ResetRequest findRequestByEmail(String email) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM ResetRequests WHERE email = ?");
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String otp = rs.getString("otp");
                Timestamp expirationTime = rs.getTimestamp("expirationTime");
                return new ResetRequest(email, otp, expirationTime.toInstant()); // Create and return the ResetRequest object
            }
        } catch (SQLException e) {
            System.err.println("Error finding reset request: " + e.getMessage());
        }
        return null; // Return null if no request found for the email
    }

    // This method updates the password for the user with the specified email.
    public void updateUserPassword(String email, String newPassword) {
        try {
            // Update the user's password in the Users table based on the email
            PreparedStatement stmt = connection.prepareStatement("UPDATE Users SET password = ? WHERE email = ?");
            stmt.setString(1, newPassword);
            stmt.setString(2, email);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Password updated successfully for email: " + email);
            } else {
                System.err.println("No user found with email: " + email);
            }
        } catch (SQLException e) {
            System.err.println("Error updating user password: " + e.getMessage());
        }
    }

    // This method removes the specified reset request from the database.
    public void removeRequest(ResetRequest request) {
        try {
            // Remove the reset request from the ResetRequests table
            PreparedStatement stmt = connection.prepareStatement("DELETE FROM ResetRequests WHERE email = ? AND otp = ?");
            stmt.setString(1, request.getEmail());
            stmt.setString(2, request.getOtp());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Reset request removed successfully for email: " + request.getEmail());
            } else {
                System.err.println("No reset request found for email: " + request.getEmail());
            }
        } catch (SQLException e) {
            System.err.println("Error removing reset request: " + e.getMessage());
        }
    }

//    




    


}
