package backend;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p> Title: Invitation Class. </p>
 * 
 * <p> Description: A class to manage user invitations with unique codes, associated usernames, emails, roles, and usage status. </p>
 * 
 * @version 1.2
 */

public class Invitation {
    private String invitationCode;
    private String username;
    private String email;
    private Set<Role> roles;
    private boolean isUsed;
    private Connection connection;

    // Constructor to create a new invitation with a database connection
    public Invitation(Connection connection, String username, String email, Set<Role> roles) {
        this.connection = connection;
        this.invitationCode = UUID.randomUUID().toString();
        this.username = username;
        this.email = email;
        this.roles = roles != null ? roles : new HashSet<>();
        this.isUsed = false;
    }

    // Constructor to retrieve an invitation from the database without creating a new one
    private Invitation(Connection connection, String invitationCode, String username, String email, Set<Role> roles, boolean isUsed) {
        this.connection = connection;
        this.invitationCode = invitationCode;
        this.username = username;
        this.email = email;
        this.roles = roles;
        this.isUsed = isUsed;
    }

    public Invitation(String invitationCode, String username, String email, Object roles) {
        this.invitationCode = invitationCode;
        this.username = username;
        this.email = email;

        // If roles is a Set<Role>, cast it; otherwise, initialize an empty set
        if (roles instanceof Set<?>) {
            this.roles = ((Set<?>) roles).stream()
                                          .filter(role -> role instanceof Role)
                                          .map(role -> (Role) role)
                                          .collect(Collectors.toSet());
        } else {
            this.roles = new HashSet<>(); // Initialize as empty set if roles is not a Set<Role>
        }

        this.isUsed = false; // Default to not used
    }


	// Invite a user by creating an invitation and saving it to the database
    public static String inviteUser(Connection connection, String username, String email, Set<Role> roles) {
        Invitation invitation = new Invitation(connection, username, email, roles);
        invitation.addInvitationToDatabase();
        System.out.println("Invitation code for " + email + " : " + invitation.getInvitationCode());
        return invitation.getInvitationCode();
    }

    // Get invitation from the database by invitation code
    public static Invitation getInvitationByCode(Connection connection, String invitationCode) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Invitations WHERE invitationCode = ? AND used = FALSE");
            stmt.setString(1, invitationCode);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String rolesString = rs.getString("roles");
                Set<Role> roles = Arrays.stream(rolesString.split(","))
                                        .map(Role::valueOf)
                                        .collect(Collectors.toSet());
                return new Invitation(connection, rs.getString("invitationCode"), rs.getString("username"), 
                                      rs.getString("email"), roles, rs.getBoolean("used"));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving invitation: " + e.getMessage());
        }
        return null;
    }

    // Mark the invitation as used and update the database
    public void markAsUsed() {
        this.isUsed = true;
        updateInvitationInDatabase();
    }

    // Method to add invitation to the database
    private void addInvitationToDatabase() {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "INSERT INTO Invitations (invitationCode, username, email, roles, used) VALUES (?, ?, ?, ?, ?)"
            );
            stmt.setString(1, invitationCode);
            stmt.setString(2, username);
            stmt.setString(3, email);
            String rolesString = roles.stream()
                                      .map(Role::name)
                                      .collect(Collectors.joining(","));
            stmt.setString(4, rolesString);
            stmt.setBoolean(5, isUsed);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding invitation to database: " + e.getMessage());
        }
    }

    // Update invitation usage status in the database
    private void updateInvitationInDatabase() {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE Invitations SET used = ? WHERE invitationCode = ?");
            stmt.setBoolean(1, isUsed);
            stmt.setString(2, invitationCode);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating invitation in database: " + e.getMessage());
        }
    }

    // Delete an invitation by invitation code
    public static boolean deleteInvitation(Connection connection, String invitationCode) {
        try {
            PreparedStatement stmt = connection.prepareStatement("DELETE FROM Invitations WHERE invitationCode = ?");
            stmt.setString(1, invitationCode);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting invitation: " + e.getMessage());
        }
        return false;
    }

    // List all invitations (for debugging or admin purposes)
    public static void listInvitations(Connection connection) {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Invitations");
            while (rs.next()) {
                System.out.println("Invitation Code: " + rs.getString("invitationCode"));
                System.out.println("Username: " + rs.getString("username"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Roles: " + rs.getString("roles"));
                System.out.println("Used: " + rs.getBoolean("used"));
                System.out.println();
            }
        } catch (SQLException e) {
            System.err.println("Error listing invitations: " + e.getMessage());
        }
    }

    // Getters
    public String getInvitationCode() {
        return invitationCode;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public boolean isUsed() {
        return isUsed;
    }
}
