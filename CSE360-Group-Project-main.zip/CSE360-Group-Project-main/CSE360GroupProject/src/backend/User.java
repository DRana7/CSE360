package backend;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class User {
    private String username;
    private String password; // Consider hashing passwords in production
    private Set<Role> roles; // Assuming Role is an enum
    private String firstName;
    private String middleName;
    private String lastName;
    private String preferredName;
    private String email;
    private boolean setupComplete;

    // Constructor
    public User(String username, String password, Set<Role> roles) {
        this.username = username;
        this.password = password; // Store plain password, but consider hashing
        this.roles = (roles != null && !roles.isEmpty()) ? roles : new HashSet<>(); // Ensure roles are assigned properly
        this.setupComplete = false; // Default value
    }

    public User(String username, String password, Set<Role> roles, String firstName, String middleName, String lastName, String preferredName, String email) {
        this(username, password, roles); // Call the other constructor
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.preferredName = preferredName;
        this.email = email;
        this.setupComplete = true; // If fully set up
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public String getEmail() {
        return email;
    }

    public boolean isSetupComplete() {
        return setupComplete;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSetupComplete(boolean setupComplete) {
        this.setupComplete = setupComplete;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = (roles != null && !roles.isEmpty()) ? roles : new HashSet<>(); // Ensure roles is not null
    }

    // Add or remove a role
    public void addRole(Role role) {
        this.roles.add(role);
    }

    public void removeRole(Role role) {
        this.roles.remove(role);
    }

    // Method to check if the password matches
    public boolean checkPassword(String password) {
        return this.password.equals(password); // Consider using a secure comparison in production
    }

    // Method to display user information including roles
    public String displayUserInfo() {
        String rolesString = roles.stream()
            .map(Role::toString) // Assuming Role has a proper toString method
            .collect(Collectors.joining(", "));

        return String.format("Username: %s\nFirst Name: %s\nMiddle Name: %s\nLast Name: %s\nPreferred Name: %s\nRoles: %s",
                username, firstName, middleName, lastName, preferredName, rolesString.isEmpty() ? "None" : rolesString);
    }

    // Optionally, add methods for database operations if required
}
